<?php 

function firsttheme_shotcodes_scripts(){
   
    wp_enqueue_script(
        'firsttheme-shotcodes-scripts',
        plugins_url('firsttheme-shortcodes/dist/assets/js/bundle.js'), 
        ['jquery'], 
        '1.0.0', 
        true
    );

    wp_enqueue_style(
        'firsttheme-shotcodes-stylesheet', 
        plugins_url('firsttheme-shortcodes/dist/assets/css/bundle.css'), 
        array(), 
        '1.0.0', 
        'all'
    );
}
add_action('wp_enqueue_scripts', 'firsttheme_shotcodes_scripts');