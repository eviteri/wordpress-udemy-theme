<?php 
/*

[firsttheme_slider]
    [firsttheme_slide image="1691" caption="caption" /]
    [firsttheme_slide image="1686" /]
[/firsttheme_slider]

*/
function firsttheme_slider_function($atts = [], $content = null, $tag = ''){
    extract(shortcode_atts([
        //Default attributes
        'autoplay' => false,   
        'arrows' => false
    ], 
        //Atributes passed
        $atts,               
        $tag
    ));

    $html = '<div class="firsttheme_slider" data-slick=\'{"autoplay": '. ($autoplay ? 'true' : 'false')  .', "arrows": '. ( $arrows ? 'true' : 'false') .'}\'>';
    if(!is_null($content)){
        $html .= do_shortcode($content); 
    }
    $html .= '</div>';

    return $html;

}
add_shortcode('firsttheme_slider', 'firsttheme_slider_function');

//Inner content - Will be inserted in line 22 
function firsttheme_slide_function ($atts = [], $content = null, $tag = ''){
    extract(shortcode_atts([
        //Default attributes
        'image' => null,   
        'caption' => ''
    ], 
        //Atributes passed
        $atts,               
        $tag
    ));

    $html  = '<div class="firsttheme-slide">';
    if($image){
        $html .= wp_get_attachment_image($image, 'large');
    }
    if($caption){
        $html .= '<div class="firsttheme-slide-caption">' . esc_html($caption) . '</div>';
    }
    $html .= '</div>';

    return $html;
}

add_shortcode('firsttheme_slide', 'firsttheme_slide_function');