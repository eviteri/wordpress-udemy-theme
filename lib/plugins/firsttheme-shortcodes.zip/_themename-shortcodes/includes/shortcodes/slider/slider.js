import $ from 'jquery';

$(document).ready(() => {
    $('.firsttheme_slider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,
    });
});
          