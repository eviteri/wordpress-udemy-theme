<?php 
// [firsttheme_icon icon="fas fa-search" /]
// function firsttheme_icon($atts){
//     extract(shortcode_atts([
//         'icon' => '',   //Default attributes
//     ], 
//         $atts               //Atributes passed
//     ));

//     return '<i class="'.esc_attr($icon).'" aria-hidden ></i>';
// }

// add_shortcode(
//     'firsttheme_icon', //shortcode name
//     'firsttheme_icon'  //function name
// );
//client-solutions
//Short code
// [firsttheme_button color="#f03" text="text" /]
/*
function firsttheme_button($atts){
    extract(shortcode_atts([
        'color' => 'red',   //Default attributes
        'text' => 'Button'
    ], 
        $atts               //Atributes passed
    ));

    return '<button style="background-color: '. esc_attr($color).'">'.esc_html($text).'</button>';
}

add_shortcode(
    'firsttheme_button', //shortcode name
    'firsttheme_button'  //function name
);
*/

//[firsttheme_button]text[/firsttheme_button]
function firsttheme_button($atts = [], $content = null, $tag = ''){
    extract(shortcode_atts([
        'color' => 'red',   //Default attributes
        'text' => 'Button'
    ], 
        $atts,               //Atributes passed
        $tag
    ));

    //return '<button style="background-color: '. esc_attr($color).'">'.esc_html($content).'</button>';

    // [firsttheme_button][firsttheme_icon icon="fas fa-search" /]text[/firsttheme_button]
    return '<button class="firsttheme_button" style="background-color: '. esc_attr($color).'">'.do_shortcode($content).'</button>';
}

add_shortcode(
    'firsttheme_button', //shortcode name
    'firsttheme_button'  //function name
);


