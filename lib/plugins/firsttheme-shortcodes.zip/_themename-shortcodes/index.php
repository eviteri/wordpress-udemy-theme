<?php 
/*
Plugin Name:    firsttheme shotcodes
Plugin URI:
Description:    Adding Shortcodes for firsttheme
Version:        1.0.0
Author:         Eloy Viteri 
Author URI:     http://www.eviteri.com
License:        GPL2
License URI:    https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:    firsttheme-shotcodes
Domain Path:    /languages
*/

// if(!define('WPINC')){
//     die;
// }


function firsttheme_shotcodes_init(){
    include_once('includes/shortcodes/button/button.php');
    include_once('includes/shortcodes/slider/slider.php');
}
add_action('init', 'firsttheme_shotcodes_init');


include_once('includes/enqueue-assets.php');
